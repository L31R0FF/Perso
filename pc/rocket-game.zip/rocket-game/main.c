/*
 * main.c
 * 
 * Copyright 2017 l31r0ff <l31r0ff@laposte.net>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
#include <stdbool.h>

/* Réinitialise les positions d'un astéroide */
SDL_Rect newpos(SDL_Rect positionAstero, const int MAX, const int MIN, const int MAX2, const int MIN2)
{
    positionAstero.y = (rand() % (MAX2 - MIN2 + 1)) + MIN2;
    positionAstero.x = (rand() % (MAX - MIN + 1)) + MIN;
    return positionAstero;
}

bool check_collision( SDL_Rect A, SDL_Rect B )
{
    //Les côtés des rectangles
    int leftA, leftB;
    int rightA, rightB;
    int topA, topB;
    int bottomA, bottomB;
    //Calculer les côtés du rect A
    leftA = A.x;
    rightA = A.x + A.w;
    topA = A.y;
    bottomA = A.y + A.h;        
    //Calculer les côtés du rect B
    leftB = B.x;
    rightB = B.x + B.w;
    topB = B.y;
    bottomB = B.y + B.h;
    //Si un des côtés de A sont en dehors de B
    if( bottomA <= topB )
    {
        return false;
    }    
    if( topA >= bottomB )
    {
        return false;
    }    
    if( rightA <= leftB )
    {
        return false;
    }    
    if( leftA >= rightB )
    {
        return false;
    }    
    //Si aucun des côtés de A sont en dehors de B
    return true;
}

/* Affiche un texte à l'écran et attend un événement */
void titleScreen(SDL_Surface *ecran, int x, int y, TTF_Font *police, char texte[], SDL_Color couleur)
{
    /* Préparation les variables */
    SDL_Rect position;
    position.x = x;
    position.y = y;
    
    SDL_Surface *stexte = NULL;
    stexte = TTF_RenderText_Blended(police, texte, couleur);
    SDL_Event event;
    int continuer = 1;
    /* Afficher le texte et attendre un évenement */
    while (continuer)
    {
        SDL_BlitSurface(stexte, NULL, ecran, &position);
        SDL_Flip(ecran);

        SDL_WaitEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
                continuer = 0;
                break;
            case SDL_KEYDOWN:
                switch(event.key.keysym.sym)
                {
                    case SDLK_SPACE: // Espace
                        continuer = 0;
                        break;
                }
                break;
        }        
    }
    SDL_FreeSurface(stexte);
}

int main(int argc, char *argv[])
{
    srand(time(NULL));

    /* Définition des Integer */
    int vies = 100;
    int score = 0;
    int continuer = 1;
    int i;
    int speed = 2;
    int persofile = 1;
    int passage;
    const int MAX = 600, MIN = 0, MAX2 = 50, MIN2 = 0;

    /* Définition des surfaces et rect */ 
    SDL_Surface *ecran = NULL, *perso = NULL, *asteroid = NULL, *texteVies = NULL, *fond = NULL;
    SDL_Rect positionPerso, textePos, fondPos;
    SDL_Rect positionAsteros[5];
    textePos.x = 0;
    textePos.y = 0;
    fondPos.x = 0;
    fondPos.y = 0;
    SDL_Event event;

    /* Création de la fenêtre */
    SDL_Init(SDL_INIT_VIDEO);
    TTF_Init();
    if(Mix_OpenAudio(22050, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 1024) == -1) //Initialisation de l'API Mixer
    {
        printf("%s", Mix_GetError());
    }
    SDL_WM_SetIcon(SDL_LoadBMP("utils/rocket_icone.bmp"), NULL);
    ecran = SDL_SetVideoMode(640, 480, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    SDL_WM_SetCaption("Rocket", NULL);

    /* Chargement de Perso */
    perso = IMG_Load("utils/rocket.png");
    asteroid = IMG_Load("utils/asteroid.png");
    fond = SDL_LoadBMP("utils/fond.bmp");

    /* Ouverture des polices et définition des couleurs */
    TTF_Font *arcade = NULL;
    TTF_Font *Barcade = NULL;
    arcade = TTF_OpenFont("utils/arcadeclassic.ttf", 30);
    Barcade = TTF_OpenFont("utils/arcadeclassic.ttf", 65);
    SDL_Color rouge = {255, 0, 0};
    SDL_Color blanc = {255, 255, 255};

    /* Ouverture des musiques et effets sonores */
    Mix_AllocateChannels(3);
    Mix_Music *musique;
    musique = Mix_LoadMUS("utils/musique.wav");
    Mix_Chunk *gameOver;
    gameOver = Mix_LoadWAV("utils/gameover.wav");
    Mix_Chunk *bip;
    bip = Mix_LoadWAV("utils/bip.wav");

    /* Ecran de démarrage */
    SDL_BlitSurface(fond, NULL, ecran, &fondPos);
    titleScreen(ecran, 150, 180, Barcade, "PRESS SPACE", blanc);

    Mix_PlayMusic(musique, -1);

    /* On initialise la position des astéroides */
    for (i = 0; i < 5; i++)
    {
        positionAsteros[i] = newpos(positionAsteros[i], MAX, MIN, MAX2, MIN2);
    }

    /* On centre Perso à l'écran */
    positionPerso.x = ecran->w / 2 - perso->w / 2;
    positionPerso.y = ecran->h / 2 + 180 - perso->h / 2;

    SDL_EnableKeyRepeat(10, 10);
    int tempsPrecedent = 0, tempsActuel = 0;
    while (continuer)
    {
        /* Changer le sprite de la fusée */
        if (persofile == 1)
        {
            perso = IMG_Load("utils/rocket.png");            
        }
        else
        {
            perso = IMG_Load("utils/rocket2.png");
        }

        /* Récupérer les évenements (façon non bloquante) */
        SDL_PollEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
                continuer = 0;
                break;
            case SDL_KEYDOWN:
                switch(event.key.keysym.sym)
                {
                    case SDLK_RIGHT: // Flèche droite
                        if (positionPerso.x <= 600)
                        {
                            positionPerso.x = positionPerso.x + 3;
                        }
                        break;
                    case SDLK_LEFT: // Flèche gauche
                        positionPerso.x = positionPerso.x - 3;
                        break;
                    case SDLK_p: // p, mettre en pause
                        Mix_PauseMusic();
                        titleScreen(ecran, 150, 180, Barcade, "PRESS SPACE", blanc);
                        Mix_ResumeMusic();
                        break;
                    case SDLK_ESCAPE: // p, mettre en pause
                        continuer = 0;
                        break;
                }
                break;
        }

        /* On place le fond */
        SDL_BlitSurface(fond, NULL, ecran, &fondPos);

        /* On place les astéroides a leur position */
        for (i = 0; i < 5; i++)
        {
                SDL_BlitSurface(asteroid, NULL, ecran, &positionAsteros[i]);
        }

        /* On place Perso à sa nouvelle position */
        SDL_BlitSurface(perso, NULL, ecran, &positionPerso);

        /* Texte du haut */
        char hud[30];
        sprintf(hud, "Vies  %d  Score  %d", vies, score); 
        texteVies = TTF_RenderText_Blended(arcade, hud, blanc);
        SDL_BlitSurface(texteVies, NULL, ecran, &textePos);

        /* On met à jour l'affichage */
        SDL_Flip(ecran);

        /* Toute les 10 ms */
        tempsActuel = SDL_GetTicks();
        if (tempsActuel - tempsPrecedent > 10) /* Si 10 ms se sont écoulées */
        {
            /* Changer le sprite de la fusée (flammes) */
            if (persofile == 1)
            {
                persofile = 2;
            }
            else
            {
                persofile = 1;
            }
            
            /* Déplace les astéroides vers le bas et aléatoire sur le coté */
            for (i = 0; i < 5; i++)
            {
                positionAsteros[i].y = positionAsteros[i].y + speed;
                positionAsteros[i].x = positionAsteros[i].x + (rand() % (5 - -5 + 1)) + -5;
            }

            tempsPrecedent = tempsActuel; /* Le temps "actuel" devient le temps "precedent" pour nos futurs calculs */
        }

        /* Si un astéroide n'est plus visible, réinitialiser sa position */
        for (i = 0; i < 5; i++)
        {
            if (positionAsteros[i].y >= 480)
            {
                positionAsteros[i] = newpos(positionAsteros[i], MAX, MIN, MAX2, MIN2);
                
                if (i == 4)
                {
                    passage++;
                    score++;
                }    
            }
            /* Si la fusée entre en collision avec un astéroide lui enlever de la vie */
            if (check_collision(positionPerso, positionAsteros[i])) {
                Mix_PlayChannel(1, bip, 0);
                vies--;
                /* Si on a plus de vies : Game Over */
                if (vies < 0)
                {
                    Mix_PauseMusic();
                    Mix_PlayChannel(2, gameOver, 0);
                    titleScreen(ecran, 180, 180, Barcade, "GAME OVER", rouge);
                    continuer = 0;
                    break;
                }
            } 
        }

        /* Augmenter la vitesse au bout de 10 passages */
        if (passage >= 10)
        {
            speed = speed + 1;
            passage = 0;
        }        

    }

    /* Nettoyage */
    SDL_FreeSurface(perso);
    SDL_FreeSurface(asteroid);
    SDL_FreeSurface(texteVies);
    SDL_FreeSurface(fond);
    Mix_FreeMusic(musique);
    Mix_FreeChunk(gameOver);
    Mix_FreeChunk(bip);
    TTF_CloseFont(arcade);
    TTF_CloseFont(Barcade);
    TTF_Quit();
    Mix_CloseAudio();
    SDL_Quit();
    return EXIT_SUCCESS;
}