#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pygame, random, math
from pygame.locals import *

pygame.init()
pygame.mixer.init()

fenetre = pygame.display.set_mode((800, 600))
pygame.key.set_repeat(80, 80)

fond = pygame.image.load("fond.png")
sol = pygame.image.load("floor.png")
wall = pygame.image.load("wall.png")
lightwall = pygame.image.load("lightwall.png")
pygame.mixer.music.load("music.ogg")
pygame.mixer.music.set_volume(0.5)

# classe mère du joueur et des monstres
class Thing :
    def __init__(self, nom, x, y):
        self.nom = nom
        self.health = 100 # santé
        self.att = False # Si il attaque

        # différents sprites de la chose (forme 1 et 2)
        self.up = pygame.image.load(nom + "u.png").convert_alpha()
        self.upi = pygame.image.load(nom + "ui.png").convert_alpha()

        self.down = pygame.image.load(nom + "d.png").convert_alpha()
        self.downi = pygame.image.load(nom + "di.png").convert_alpha()

        self.right = pygame.image.load(nom + "r.png").convert_alpha()
        self.righti = pygame.image.load(nom + "ri.png").convert_alpha()

        self.left = pygame.image.load(nom + "l.png").convert_alpha()
        self.lefti = pygame.image.load(nom + "li.png").convert_alpha()

        # sprites d'attaque
        self.aup = pygame.image.load(nom + "au.png").convert_alpha()
        self.aupi = pygame.image.load(nom + "aui.png").convert_alpha()

        self.adown = pygame.image.load(nom + "ad.png").convert_alpha()
        self.adowni = pygame.image.load(nom + "adi.png").convert_alpha()

        self.aright = pygame.image.load(nom + "ar.png").convert_alpha()
        self.arighti = pygame.image.load(nom + "ari.png").convert_alpha()

        self.aleft = pygame.image.load(nom + "al.png").convert_alpha()
        self.alefti = pygame.image.load(nom + "ali.png").convert_alpha()

        self.msprite = self.down # sprite principal (celui affiché)
        self.psprite = self.msprite

        self.hit = pygame.mixer.Sound(self.nom + "h.ogg") 

        self.speed = 10
        self.pos = self.left.get_rect()
        self.pos = self.pos.move(x,y)
        self.state = 1 # etat de la chose (pour l'animation)
        self.fpos = 0

    # attaque la cible (sante - degats)
    def attack(self, cible) :
        if self.msprite == self.up :
            self.msprite = self.aup

        elif self.msprite == self.upi :
            self.msprite = self.aupi

        elif self.msprite == self.down :
            self.msprite = self.adown

        elif self.msprite == self.downi :
            self.msprite = self.adowni

        elif self.msprite == self.left :
            self.msprite = self.aleft

        elif self.msprite == self.lefti :
            self.msprite = self.alefti

        elif self.msprite == self.right :
            self.msprite = self.aright

        elif self.msprite == self.righti :
            self.msprite = self.arighti

        dist = math.hypot(self.pos.x-cible.pos.x, self.pos.y-cible.pos.y)
        if dist <= 25 and self.attack != True :
            cible.hit.play()
            print("attacked " + cible.nom)
            cible.health = cible.health - self.degats


# classe du joueur
class Player(Thing) :
    def __init__(self, nom, x, y):
        Thing.__init__(self, nom, x, y)
        self.degats = 50

    # permet de déplacer le joueur
    def move(self, direction, wallist) :
        if direction == "up" :
            self.fpos = self.pos.move(0,-self.speed) # future position
            if self.fpos.collidelist(wallist) == -1 : # si la future position n'est pas sur un mur
                self.pos = self.pos.move(0,-self.speed)
                # si l'anim est à 1, l'afficher et anim à 2
                if self.state == 1 :
                    self.msprite = self.up
                    self.state = 2
                elif self.state == 2 :
                    self.msprite = self.upi
                    self.state = 1

        elif direction == "down" :
            self.fpos = self.pos.move(0,self.speed) 
            if self.fpos.collidelist(wallist) == -1 :
                self.pos = self.pos.move(0,self.speed)
                if self.state == 1 :
                    self.msprite = self.down
                    self.state = 2
                elif self.state == 2 :
                    self.msprite = self.downi
                    self.state = 1

        elif direction == "left" :
            self.fpos = self.pos.move(-self.speed,0)
            if self.fpos.collidelist(wallist) == -1 :
                self.pos = self.pos.move(-self.speed,0)
                if self.state == 1 :
                    self.msprite = self.left
                    self.state = 2
                elif self.state == 2 :
                    self.msprite = self.lefti
                    self.state = 1

        elif direction == "right" :
            self.fpos = perso.pos.move(perso.speed,0)
            if self.fpos.collidelist(wallist) == -1 :
                perso.pos = perso.pos.move(perso.speed,0)
                if perso.state == 1 :
                    perso.msprite = perso.right
                    perso.state = 2
                elif perso.state == 2 :
                    perso.msprite = perso.righti
                    perso.state = 1

# classe des monstres (hérite de Thing)            
class Monster(Thing) :
    def __init__(self, nom, x, y):
        Thing.__init__(self, nom, x, y)
        self.degats = 5

    # cherche le joueur
    def search(self, player): # chase movement
        dist = math.hypot(self.pos.x-player.pos.x, self.pos.y-player.pos.y)
        
        monstpos = []
        for monst in monstlist :
            if monst.pos != self.pos :
                monstpos.append(monst.pos)

        # si le joueur est à 25 px de lui, attaquer
        if dist <= 25 :
            self.attack(player)
        # si le joueur est à 200 px de lui (rayon d'action), marcher vers lui
        elif dist < 200 :
            # Movement along x direction        
            if self.pos.x > player.pos.x :
                self.fpos = self.pos.move(-self.speed, 0)
                if self.fpos.collidelist(wallist) == -1 and self.fpos.collidelist(monstpos) == -1 :
                    self.pos.x -= self.speed
                    if self.state == 1 :
                        self.msprite = self.left
                    elif self.state == 2 :
                        self.msprite = self.lefti

            elif self.pos.x < player.pos.x :
                self.fpos = self.pos.move(self.speed, 0)
                if self.fpos.collidelist(wallist) == -1 and self.fpos.collidelist(monstpos) == -1 :
                    self.pos.x += self.speed
                    if self.state == 1 :
                        self.msprite = self.right
                    elif self.state == 2 :
                        self.msprite = self.righti

            # Movement along y direction
            if self.pos.y < player.pos.y :
                self.fpos = self.pos.move(0, self.speed)
                if self.fpos.collidelist(wallist) == -1 and self.fpos.collidelist(monstpos) == -1 :
                    self.pos.y += self.speed
                    if self.state == 1 :
                        self.msprite = self.down
                    elif self.state == 2 :
                        self.msprite = self.downi

            elif self.pos.y > player.pos.y :
                self.fpos = self.pos.move(0, -self.speed)
                if self.fpos.collidelist(wallist) == -1 and self.fpos.collidelist(monstpos) == -1 :
                    self.pos.y -= self.speed
                    if self.state == 1 :
                        self.msprite = self.up
                    elif self.state == 2 :
                        self.msprite = self.upi

            # alterne les états (évite que les x
            # et les y le change en diagonale)
            if self.state == 1 :
                self.state = 2

            elif self.state == 2 :
                self.state = 1
             
# prend une liste de positions et les 
# transforme en rect d'un objet donné
def pos2rect(posList, sprite) :
    rectList = []
    for pos in posList :
        nrect = sprite.get_rect()
        nrect.x = pos[0]
        nrect.y = pos[1]
        rectList.append(nrect)
    return rectList

def pos2monst(posList, nom) :
    monstList = []
    for pos in posList :
        monst = Monster(nom, pos[0], pos[1])
        monstList.append(monst)
    return monstList

# ouvre la carte des sprites indiqués
def openMap(nom, sprName) :
    with open(nom, "r") as fichier :
        myMap = fichier.read()
        myMap = myMap.split("\n")
        x = 0
        y = 0
        poslist = []
        for ligne in myMap :
            for lettre in ligne :
                if lettre == sprName :
                    poslist.append([x,y])
                x = x + 25
            y = y + 25
            x = 0                    
        return poslist

def blitMap(nom) :
    with open(nom, "r") as fichier :
        myMap = fichier.read()
        myMap = myMap.split("\n")
        x = 0
        y = 0
        poslist = []
        for ligne in myMap :
            for lettre in ligne :
                if lettre == "w" :
                    fenetre.blit(wall, (x,y))

                elif lettre == "W" :
                    fenetre.blit(lightwall, (x,y))

                elif lettre == " " :
                    fenetre.blit(sol, (x,y))

                elif lettre == "m" :
                    fenetre.blit(sol, (x,y))

                x = x + 25
            y = y + 25
            x = 0

# wallist = pos2rect([[0,0],[0,25],[0,50],[0,75],[0,100],[25,0],[50,0],[75,0],[100,0],[100,25],[100,50],[100,75],[100,100],[75,100],[50,100],[25,100]], wall)
wallist = pos2rect(openMap("map2.txt", "W"), wall)
monstlist = pos2monst(openMap("map2.txt", "m"), "m")
perso = Player("p", 25, 25)
tempsPrecedent = 0
game = True
pygame.mixer.music.play(-1)

while game :
    for event in pygame.event.get():
        if event.type == QUIT:
            game = False
        if event.type == KEYDOWN :
            if event.key == K_z :
                perso.move("up", wallist) 

            elif event.key == K_s :
                perso.move("down", wallist)

            elif event.key == K_q :
                perso.move("left", wallist)

            elif event.key == K_d :
                perso.move("right", wallist)

            elif event.key == K_g :
                perso.att = True
                perso.psprite = perso.msprite
                for monst in monstlist :
                    perso.attack(monst)
                    if monst.health <= 0 :
                        monstlist.remove(monst)

    # tous les 500 millis
    tempsActuel = pygame.time.get_ticks()
    if tempsActuel - tempsPrecedent > 200 :
        print(perso.health)
        # pour chaque monstre
        for monst in monstlist :
            # chercher perso
            monst.search(perso)

        # si le perso à attaqué
        if perso.att :
            # mettre le sprite d'avant l'attaque
            perso.msprite = perso.psprite
            perso.att = False

        tempsPrecedent = tempsActuel

    # quitter si le joueur n'a plus de vie
    if perso.health <= 0 :
        game = False

    #fenetre.blit(fond, (0,0))

    blitMap("map2.txt")

    # affiche les murs
    #for wallpos in wallist :
    #   fenetre.blit(wall, wallpos)

    # affiche les monstres
    for monst in monstlist :
        fenetre.blit(monst.msprite, monst.pos)

    fenetre.blit(perso.msprite, perso.pos)

    pygame.display.flip()